# 企业名单工作台 Skills

本包包含两个相互独立的 Skill：

- `enterprise-lead-workbench`：收敛找企业条件、说明调用量、生成和管理真实企业名单。
- `enterprise-public-report`：对已入库企业调用 Ego Lite，生成带来源与覆盖说明的 HTML 报告。

两者依赖同一个企业名单工作台 MCP。WorkBuddy 可把本目录作为插件安装；其他支持 `SKILL.md` 的 Agent 可分别安装两个 Skill 目录。部署凭证只放在工作台服务端，不放入 Skill 包。
