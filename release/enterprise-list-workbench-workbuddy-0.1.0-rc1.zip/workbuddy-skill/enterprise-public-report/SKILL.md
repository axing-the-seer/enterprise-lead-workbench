---
name: enterprise-public-report
description: 为企业名单中已入库的单个企业生成可追溯的 Ego Lite HTML 公开信息报告，汇总官网与业务、招聘和公开新闻。适用于企业详情、公司调研和 HTML 报告；不用于凭空找企业或工商核验。
---

# 企业公开信息报告

本 Skill 只处理“已入库企业 → 公开信息报告”。它调用本机 Ego Lite 检索公开网页，并把结果写回企业名单工作台。企业身份与工商字段仍以获客助手/企查查事实为准。

## 执行

1. 用 `list_workspaces` 确认工作空间。
2. 用 `list_companies` 按名单或名称查找企业。名称出现多个候选时，展示企业名、信用代码和地区，让用户确认；不得默认选第一家。
3. 用 `list_source_connections` 找到 `web_search`。只有 `ready` 或 `degraded` 时继续；否则引导用户在 Web UI 的“配置”中检查 Ego Lite。
4. 执行前说明：将检索公司官网/业务、招聘网站和公开新闻；登录页、验证码和站点限制不会绕过；没有找到不等于没有相关事实。
5. 调用 `start_ingestion_query`：
   - `queryKind`: `web_evidence`
   - `criteria.companyId`: 已确认企业 ID
   - `criteria.claimType`: `public_report`
   - `criteria.reportMode`: `true`
   - `criteria.maxResults`: 1–10，默认 6
   - `idempotencyKey`: 同一请求重试复用
6. 用 `list_ingestion_jobs` 轮询任务。`completed` 表示全覆盖完成，`partial` 表示部分来源受限但报告仍可查看，`failed` 才是失败。
7. 当 `reportAvailable` 为 true，引导用户从企业详情的“公开信息报告”或任务对应的 Web UI 报告页打开、打印、下载 HTML。报告任务 ID 就是路由标识，路由片段为 `/#/reports/{jobId}`；如果运行环境提供工作台基址，可拼成可点击链接，否则只给路由片段，不猜部署地址。MCP 不返回 HTML 正文。

报告规范见 [references/report-standard.md](references/report-standard.md)。

## 边界

- 不用公开网页创建企业主体；企业必须先在工作台入库。
- 不把搜索摘要写成确定事实。每条内容保留 URL、标题、抓取时间、覆盖状态、主体相关度和链接类型。
- 默认先呈现“匹配本企业”的证据；“关联主体”和“行业背景”必须明确标注，不能混写成当前企业事实。
- 不绕过登录、验证码、付费墙、robots 或站点限制。
- 不因没有检索到信息而写“没有招聘”“没有新闻”或“无风险”。
- 不把同名企业的网页证据自动归给当前企业；身份不确定时标为待核验。
- 报告不是法律、征信或尽调结论。
