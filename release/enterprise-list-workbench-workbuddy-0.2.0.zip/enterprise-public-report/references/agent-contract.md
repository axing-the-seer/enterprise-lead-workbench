# Agent 分析契约

## 读取策略

`get_company_report_context` 返回企业工商概况、当前字段事实和证据目录。目录只用于选材；形成判断前，用 `read_company_report_evidence` 读取相关证据正文。每次最多读取 10 条，优先读取：

1. 与企业全称匹配且来源为官网的材料。
2. 与用户目标相关的招聘、新闻和业务材料。
3. 用于交叉验证同一事件的第二来源。

`related_entity` 只能作为关联主体线索，`broad_context` 只能作为行业背景。

## 回传结构

提交给 `submit_company_report_analysis` 的 `analysis` 必须符合：

```json
{
  "schemaVersion": "company-agent-analysis.v1",
  "title": "可选的报告标题",
  "executiveSummary": "面向业务用户的简明结论",
  "executiveEvidenceIds": ["ev-001"],
  "businessProfile": [],
  "growthSignals": [],
  "recentEvents": [],
  "opportunities": [],
  "risks": [],
  "recommendedActions": [],
  "limitations": []
}
```

六个分析数组中的每一项使用相同结构：

```json
{
  "title": "短标题",
  "summary": "说明事实、判断依据及与用户目标的关系",
  "confidence": "high",
  "evidenceIds": ["ev-001", "ev-003"],
  "happenedAt": "2026-08-24T00:00:00+08:00"
}
```

- `confidence` 只允许 `high`、`medium`、`low`。
- `happenedAt` 可省略；不得根据抓取时间猜测事件发生时间。
- `opportunities` 必须结合用户的产品、服务或本次分析目的；未提供业务背景时，写成“待结合用户业务验证”的中性机会线索。
- `risks` 同时包含负面事实与数据不确定性，但不得把未检索到写成无风险。
- `recommendedActions` 必须具体到下一步动作，并引用触发该动作的证据。

## 报告质量

统一模板固定展示：结论摘要、企业概况、企业与业务理解、发展与招聘信号、近期公开动态、潜在合作机会、风险与不确定性、建议下一步、分析限制和证据附录。Agent 只提交结构化内容，不自行编写 HTML 或修改品牌版式。
