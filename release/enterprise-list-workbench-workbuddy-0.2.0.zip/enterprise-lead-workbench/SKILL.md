---
name: enterprise-lead-workbench
description: 把“想找什么企业”收敛成获客助手支持的真实筛选条件，说明调用量并在用户确认后创建可追溯企业名单。适用于找企业、潜在客户名单、工商核验和名单导出；不负责公开网页企业报告。
---

# 企业名单工作台

本 Skill 是“找企业”入口。对话用于收敛需求和发起任务，Web UI 是名单管理、逐家查看、核验和导出的完整界面；二者使用同一数据和任务状态。

## 开始前

1. 用 `list_workspaces` 选择工作空间。
2. 用 `list_source_connections` 检查 `huoke_assistant`。只有 `ready` 或 `degraded` 才能发起真实查询；未就绪时引导用户在 Web UI 右上角“配置”中检查连接。
3. 不向用户索取或复述 Key。凭证只能由部署环境管理。

## 收敛需求

先确认“行业或关键词、地区、数量”，再从以下有效维度中补问至少一类：注册资本、参保人数、成立日期、企业类型、正常经营、实际经营、电话/邮箱、企业资质、风险排除。优先把结果收敛在 10–50 家。

只使用获客助手真实支持的字段。字段结构和约束见 [references/kc-query-contract.md](references/kc-query-contract.md)。地区和行业必须来自获客助手目录；如果当前 Agent 不能取得目录值，就把已确认的人类可读条件交给 Web UI 选择，不能猜供应商内部编码。

## 调用确认

获客助手每页最多 10 家。执行前必须向用户展示：完整条件、目标企业数、预计调用次数 `ceil(数量/10)`、电话与邮箱同时选择时为“同时满足”、多维条件通常取交集。只有用户明确确认后才调用。

## 创建和交付名单

有完整目录值时，使用 `start_ingestion_query`：

- `queryKind`: `company_search`
- `sourceConnectionId`: 已就绪的获客助手连接
- `criteria`: 已确认条件，并按页设置 `page` 与 `pageSize`（1–10）
- `listName`: 同一轮分页必须完全一致；使用“地区 · 行业/关键词”等简洁名称，不得自动追加日期或时间
- `origin`: 固定传 `{"channel":"agent","provider":"workbuddy","agentName":"WorkBuddy"}`，供 Web UI 清晰标记“WorkBuddy 创建”
- `idempotencyKey`: 同一页重试复用，下一页使用不同值

用 `list_ingestion_jobs` 轮询。只有 `completed` 或 `partial` 才算结束；`queued`、`running` 只是处理中。然后用 `list_company_lists` 和 `list_companies` 返回真实结果，并提示用户在“我的名单”继续管理。

交接到 Web UI 时返回名单 ID 和路由片段 `/#/lists/{companyListId}`。如果运行环境提供了工作台基址，可拼成可点击链接；没有基址时只给路由片段，不猜测域名、端口或部署地址。

用户要求工商核验时，仅对已入库企业调用企查查 `company_detail`。当前生产适配器只保证基本工商登记信息，不宣称支持企查查名单搜索、司法风险、招投标或知识产权。

## 不变量

- 企业及字段必须来自获客助手、企查查或用户上传，不得补造。
- 缺失是“未知”，不是“不存在”或“无风险”。
- 冲突值、来源、抓取时间和映射版本要保留。
- 大批量或可能计费的核验必须再次说明企业数与调用量并确认。
- 公开网页报告由独立的 `enterprise-public-report` Skill 处理。

需要构造 MCP/REST 操作时读 [references/app-contract.md](references/app-contract.md)；解释来源、冲突或缺失时读 [references/source-policy.md](references/source-policy.md)。
